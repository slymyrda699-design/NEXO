 "use client";

import { useState } from "react";

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [mode, setMode] = useState("chat");
  const [message, setMessage] = useState("");

  const modes = [
    { id: "chat", name: "چت هوشمند", icon: "💬" },
    { id: "image", name: "ساخت عکس", icon: "🎨" },
    { id: "video", name: "ساخت فیلم", icon: "🎬" },
  ];

  const headings = {
    chat: "با NEXO گفتگو کن",
    image: "چه تصویری بسازیم؟",
    video: "چه فیلمی بسازیم؟",
  };

  function handleSubmit() {
    if (!prompt.trim()) {
      setMessage("لطفاً ابتدا ایده خود را بنویسید.");
      return;
    }
    setMessage("درخواست شما آماده است؛ برای اجرای واقعی باید سرویس هوش مصنوعی متصل شود.");
  }

  return (
    <main style={{
      minHeight: "100vh", background: "#080b18", color: "white",
      padding: "25px 16px", fontFamily: "Arial, sans-serif",
      textAlign: "center", display: "flex", flexDirection: "column",
      alignItems: "center"
    }}>
      <h1 style={{ color: "#a18cff", fontSize: "clamp(36px, 8vw, 48px)", marginBottom: 8 }}>
        NEXO AI
      </h1>
      <p style={{ color: "#c5c1d8", marginTop: 0 }}>قدرت خلاقیت، بدون محدودیت</p>
      <h2 style={{ marginTop: 28 }}>به دنیای هوش مصنوعی خوش آمدی</h2>

      <div style={{
        display: "flex", justifyContent: "center", flexWrap: "wrap",
        gap: 10, margin: "24px 0"
      }}>
        {modes.map((item) => (
          <button key={item.id} type="button" onClick={() => {
            setMode(item.id); setMessage("");
          }} style={{
            padding: "13px 18px", borderRadius: 12,
            border: "1px solid #8065ff",
            background: mode === item.id ? "#8065ff" : "#171b30",
            color: "white", fontSize: 15
          }}>
            {item.icon} {item.name}
          </button>
        ))}
      </div>

      <h3>{headings[mode]}</h3>
      <textarea
        value={prompt}
        onChange={(e) => { setPrompt(e.target.value); setMessage(""); }}
        placeholder="ایده خودت را اینجا بنویس..."
        aria-label="متن درخواست"
        style={{
          width: "100%", maxWidth: 550, minHeight: 140,
          padding: 15, borderRadius: 15, background: "#171b30",
          color: "white", fontSize: 17, border: "1px solid #8065ff",
          outline: "none"
        }}
      />
      <button type="button" onClick={handleSubmit} style={{
        marginTop: 18, background: "#8065ff", color: "white",
        padding: "15px 32px", border: 0, borderRadius: 14, fontSize: 17
      }}>
        شروع خلق با NEXO ✨
      </button>

      {message && <p role="status" style={{
        maxWidth: 550, lineHeight: 1.9, color: "#d7d0ff", marginTop: 18
      }}>{message}</p>}

      <footer style={{ marginTop: "auto", paddingTop: 60, color: "#777" }}>
        © 2026 NEXO AI
      </footer>
    </main>
  );
}
