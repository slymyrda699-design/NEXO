import "./globals.css";

export const metadata = {
  title: "NEXO AI",
  description: "قدرت خلاقیت با NEXO AI",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
